import UIKit

func makeItCool(_ str: String) -> String {
    var str = "Swift is awesome"
    var newStr = str.lowercased()
    
    for _ in newStr {
        if newStr.contains("a") {
            newStr.replace("a", with: "@")
        } else if newStr.contains("i") {
            newStr.replace("i", with: "1")
        } else if newStr.contains("s") {
            newStr.replace("s", with: "$")
        } else if newStr.contains("o") {
            newStr.replace("o", with: "0")
        } else if newStr.contains("t") {
            newStr.replace("t", with: "+")
        }
    }
    return newStr
}

print(makeItCool("Swift is awesome"))












////Make a functions that takes a string and makes it look “cool” by replacing some letters with another symbols
//For example we can replace “a” or “A” with @ and get “с@t” instead of “cat”
//Letters to replace: a - @; i - 1; s - $; o - 0; t - +
//(replace both capital and lowercase letters)
